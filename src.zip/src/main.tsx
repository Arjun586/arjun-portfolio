import "@fontsource/bebas-neue";
import "@fontsource/ibm-plex-sans/400.css";
import "@fontsource/ibm-plex-sans/500.css";
import "@fontsource/ibm-plex-sans/600.css";

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { initThemeSync } from "./lib/theme";
import "./index.css";

initThemeSync();

ReactDOM.createRoot(document.getElementById("root")!).render(
    <React.StrictMode>
        <App />
    </React.StrictMode>
);