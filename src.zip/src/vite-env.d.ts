declare module "@fontsource/*";
