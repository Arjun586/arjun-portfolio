import { useCallback, useSyncExternalStore } from "react";

export type Theme = "light" | "dark";

const STORAGE_KEY = "theme";
const CHANGE_EVENT = "themechange";

function readStoredTheme(): Theme | null {
    try {
        const value = window.localStorage.getItem(STORAGE_KEY);
        return value === "light" || value === "dark" ? value : null;
    } catch {
        return null;
    }
}

function getSystemTheme(): Theme {
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function getCurrentTheme(): Theme {
    const attr = document.documentElement.getAttribute("data-theme");
    return attr === "dark" || attr === "light" ? attr : getSystemTheme();
}

function applyTheme(theme: Theme) {
    document.documentElement.setAttribute("data-theme", theme);
    window.dispatchEvent(new Event(CHANGE_EVENT));
}

function setTheme(theme: Theme) {
    try {
        window.localStorage.setItem(STORAGE_KEY, theme);
    } catch {
        // Storage unavailable (e.g. private mode): the theme still applies for this session.
    }
    applyTheme(theme);
}

function subscribe(callback: () => void) {
    window.addEventListener(CHANGE_EVENT, callback);
    return () => window.removeEventListener(CHANGE_EVENT, callback);
}

/** Call once at startup. Follows OS changes until the user picks a theme, and syncs other tabs. */
export function initThemeSync() {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    media.addEventListener("change", (event) => {
        if (!readStoredTheme()) {
            applyTheme(event.matches ? "dark" : "light");
        }
    });
    window.addEventListener("storage", (event) => {
        if (event.key === STORAGE_KEY) {
            applyTheme(readStoredTheme() ?? getSystemTheme());
        }
    });
}

export function useTheme() {
    const theme = useSyncExternalStore(subscribe, getCurrentTheme, (): Theme => "light");
    const toggle = useCallback(() => {
        setTheme(getCurrentTheme() === "dark" ? "light" : "dark");
    }, []);

    return { theme, toggle };
}